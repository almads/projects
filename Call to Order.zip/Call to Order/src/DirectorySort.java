import java.io.File;
import java.util.Comparator;
import java.util.Scanner;

/**
 * This class is used for sorting and analyzing student directory data from a given file.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.02.27
 */
public class DirectorySort {

    /**
     * Finds and returns a string with students having the smallest SU box.
     *
     * @param students The list of students to search through
     * @return A string containing students with the smallest SU box
     */
    private static String getSmallestSU(SortableArrayList<Student> students){
        students.sort(new SuBoxComparator());
        String statement = students.get(0).toString();
        int smallestSUBox = students.get(0).getSuBox();
        for(int i = 1; i < students.size(); i++){
            if(students.get(i).getSuBox() == smallestSUBox){
                statement = statement + "\n" + students.get(i).toString();
            }

        }
        return statement;
    }

    /**
     * Finds and returns a string with students having the largest SU box.
     *
     * @param students The list of students to search through
     * @return A string containing students with the largest SU box
     */
    private static String getLargestSU(SortableArrayList<Student> students){
        students.sort(new SuBoxComparator());
        String statement = students.get(students.size() - 1).toString();
        int largestSUBox = students.get(students.size() - 1).getSuBox();
        for(int i = students.size() - 2; i > 0; i--){
            if(students.get(i).getSuBox() == largestSUBox){
                statement = statement + "\n" + students.get(i).toString();
            }

        }
        return statement;
    }

    /**
     * Finds and returns a string with students first in alphabetical order by last name.
     *
     * @param students The list of students to search through
     * @return A string containing the first student in alphabetical order by last name
     */
    private static String getFirstByLastName(SortableArrayList<Student> students){
        students.sort(new LastNameComparator());
        String statement = students.get(0).toString();
        String firstNameByLastName = students.get(0).getLastName();
        for(int i = 1; i < students.size(); i++){
            if(students.get(i).getLastName().equals(firstNameByLastName)){
                statement = statement + "\n" + students.get(i).toString();
            }

        }
        return statement;
    }

    /**
     * Finds and returns a string with students last in alphabetical order by last name.
     *
     * @param students The list of students to search through
     * @return A string containing the last student in alphabetical order by last name
     */
    public static String getLastByLastName(SortableArrayList<Student> students){
        students.sort(new LastNameComparator());
        String statement = students.get(students.size() - 1).toString();
        String firstNameByLastName = students.get(students.size() - 1).getLastName();
        for(int i = students.size() - 2; i > 0; i--){
            if(students.get(i).getLastName().equals(firstNameByLastName)){
                statement = statement + "\n" + students.get(i).toString();
            }

        }
        return statement;
    }

    /**
     * Finds and returns a string with students having the
     * most occurrences of vowels in their full name.
     *
     * @param students The list of students to search through
     * @return A string containing students with the
     *         most occurrences of vowels in their full name
     */
    public static String getMostVowels(SortableArrayList<Student> students){
        students.sort(new VowelsComparator());
        String statement = students.get(0).toString();
        int leastVowels = countVowels(students.get(0).getFullName());
        for(int i = 1; i < students.size(); i++){
            if(countVowels(students.get(i).getFullName()) == leastVowels){
                statement = statement + "\n" + students.get(i).toString();
            }

        }
        return statement;
    }

    /**
     * Finds and returns a string with students having
     * the least occurrences of vowels in their full name.
     *
     * @param students The list of students to search through
     * @return A string containing students with
     *         the least occurrences of vowels in their full name
     */
    public static String getLeastVowels(SortableArrayList<Student> students){
        students.sort(new VowelsComparator());
        String statement = students.get(students.size() - 1).toString();
        int mostVowels = countVowels(students.get(students.size() - 1).getFullName());
        for(int i = students.size() - 2; i > 0; i--){
            if(countVowels(students.get(i).getFullName()) == mostVowels){
                statement = statement + "\n" + students.get(i).toString();
            }

        }
        return statement;
    }

    /**
     * Counts the number of vowels in a string.
     *
     * @param s The string to count vowels from
     * @return The count of vowels in the given string
     */
    public static int countVowels(String s){
        int count = 0;
        String[] vowels = {"a", "e", "i", "o", "u"};
        for(int i = 0; i < s.length(); i++){
            for(int j = 0; j < vowels.length; j++){
                if(s.substring(i, i+1).toLowerCase().equals(vowels[j])){
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Finds and returns a string with students having
     * the most occurrences of any single digit in their phone number.
     *
     * @param students The list of students to search through
     * @return A string containing students with
     *         most occurrences of any single digit in their phone number
     */
    public static String getFancyPhone(SortableArrayList<Student> students){
        students.sort(new fancyPhoneComparator());
        String statement = students.get(0).toString();
        int mostDigits = countDigit(students.get(0).getPhone());
        for(int i = 1; i < students.size(); i++){
            if(countDigit(students.get(i).getPhone()) == mostDigits){
                statement = statement + "\n" + students.get(i).toString();
            }

        }
        return statement;
    }

    /**
     * Counts the number of most occurrences of any single digit in a string.
     *
     * @param s The string to count digits from
     * @return The most occurrences of any single digit in the given string.
     */
    public static int countDigit(String s){
        int[] counts = new int[10]; // Array to store the count of each digit
        for (char c : s.toCharArray()) {
            if (Character.isDigit(c)) {
                int digit = Character.getNumericValue(c);
                counts[digit]++;
            }
        }
        // Find the digit with the maximum occurrence
        int maxOccurrences = 0;
        for (int i = 0; i < counts.length; i++) {
            if (counts[i] > maxOccurrences) {
                maxOccurrences = counts[i];
            }
        }
        return maxOccurrences;
    }

    /**
     * The main method that executes the sorting and printing of student data.
     *
     * @param args Command line arguments
     */
    public static void main(String[] args){
        SortableArrayList<Student> students = new SortableArrayList<>();
        Scanner scan;
        try {
            scan = new Scanner(new File("directory-files/directory.txt"));
        } catch (Exception e) {
            // Failed to read file - good idea to print an error and exit/return
            System.out.println("Failed to read file.");
            return;
        }
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] parts = line.split("\\|");

            String name = parts[0].trim();
            String[] nameParts = name.split(" ");
            String firstName = nameParts[0];
            String lastName = nameParts[1];

            String address = parts[1].trim();
            String phone = parts[2].trim();
            String email = parts[3].trim();
            int suBox = Integer.parseInt(parts[4].trim());

            Student student = new Student(firstName, lastName, address, phone, email, suBox);
            students.add(student);
        }
        scan.close(); // Done reading the file, so we close the Scanner.

        // Print students with smallest SU box
        System.out.println("\nStudents with smallest SU box: \n" + getSmallestSU(students));

        // Print students with largest SU box
        System.out.println("\nStudents with largest SU box: \n" + getLargestSU(students));

        // Print first student in alphabetical order by last name
        System.out.println("\nFirst student by last name: \n" + getFirstByLastName(students));

        // Print last student in alphabetical order by last name
        System.out.println("\nLast student by last name: \n" + getLastByLastName(students));

        // Print students with most vowels in name
        System.out.println("\nStudents with most vowels in name: \n" + getMostVowels(students));

        // Print students with least vowels in name
        System.out.println("\nStudents with least vowels in name: \n" + getLeastVowels(students));

        // Print students with most occurrences of any single digit in their phone number.
        System.out.println("\nStudents with most occurrences of " +
                "single digit in phone number: \n" + getFancyPhone(students));

    }

    /**
     * The comparator for comparing students based on their SU box number.
     */
    private static class SuBoxComparator implements Comparator<Student> {
        /**
         * Compares two Student objects based on their SU box number.
         *
         * @param a the first Student to be compared
         * @param b the second Student to be compared
         * @return a negative integer, zero, or a positive integer as
         *         the first Student's SU box number
         *         is less than, equal to, or greater than the second Student's SU box number
         */
        @Override
        public int compare(Student a, Student b) {
            return a.getSuBox() - b.getSuBox();
        }
    }

    /**
     * The comparator for comparing students based on their last name.
     */
    private static class LastNameComparator implements Comparator<Student> {
        /**
         * Compares two Student objects based on their last name.
         *
         * @param a the first Student to be compared
         * @param b the second Student to be compared
         * @return a negative integer, zero, or a positive integer as
         *         the first Student's last name
         *         is less than, equal to, or greater than the second Student's last name
         */
        @Override
        public int compare(Student a, Student b) {
            return a.getLastName().compareTo(b.getLastName());
        }
    }

    /**
     * The comparator for comparing students based on the number of vowels in their names.
     */
    private static class VowelsComparator implements Comparator<Student> {
        /**
         * Compares two Student objects based on the count of vowels in their full name.
         *
         * @param a the first Student to be compared
         * @param b the second Student to be compared
         * @return a negative integer, zero, or a positive integer as
         *         the first Student's count of vowels
         *         is less than, equal to, or greater than
         *         the second Student's count of vowels in their full name
         */
        @Override
        public int compare(Student a, Student b) {
            return countVowels(b.getFullName()) - countVowels(a.getFullName());
        }
    }

    private static class fancyPhoneComparator implements Comparator<Student> {
        /**
         * Compares two Student objects based on the count of
         * most occurrences of single digit in phone number.
         *
         * @param a the first Student to be compared
         * @param b the second Student to be compared
         * @return a negative integer, zero, or a positive integer as
         *         the first Student's most occurrences of single digit in phone number
         *         is less than, equal to, or greater than
         *         the second Student's count of most occurrences of single digit in phone number
         */
        @Override
        public int compare(Student a, Student b) {
            return countDigit(b.getPhone()) - countDigit(a.getPhone());
        }
    }

}
