import java.util.Comparator;

/**
 * SortableArrayList is an extension of SimpleArrayList that provides
 * additional sorting functionality.
 * It allows you to sort the elements of the list based on a provided Comparator.
 *
 * @param <T> the type of elements in this list
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.02.27
 */
public class SortableArrayList<T> extends SimpleArrayList<T> {

    /**
     * Constructs an empty list with an initial capacity of ten.
     */
    public SortableArrayList() {
        super();
    }

    /**
     * Constructs an empty list with the specified initial capacity.
     *
     * @param startingCapacity the initial capacity of the list
     */
    public SortableArrayList(int startingCapacity) {
        super(startingCapacity);
    }

    /**
     * Sorts the elements of the list based on the specified comparator.
     *
     * @param c the comparator to use for sorting
     */
    public void sort(Comparator<? super T> c) {
        int maxIndex;
        for (int i = size() - 1; i >= 0; i--) {
            maxIndex = 0;
            for (int j = 0; j <= i; j++) {
                if (c.compare(get(j), get(maxIndex)) > 0) {
                    maxIndex = j;
                }
            }
            T temp = get(maxIndex);
            this.set(maxIndex, this.get(i));
            this.set(i, temp);
        }
    }
}
