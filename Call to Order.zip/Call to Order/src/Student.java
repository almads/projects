/**
 * The Student class represents a student with information such as first name, last name, address,
 * phone number, email address, and SU box number.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.02.27
 */
public class Student {

    /**
     * The first name of the student.
     */
    private String firstName;

    /**
     * The last name of the student.
     */
    private String lastName;

    /**
     * The address of the student.
     */
    private String address;

    /**
     * The phone number of the student.
     */
    private String phone;

    /**
     * The email address of the student.
     */
    private String email;

    /**
     * The SU box number of the student.
     */
    private int suBox;

    /**
     * Constructor to initialize the Student object with the given values.
     *
     * @param firstName the first name of the student
     * @param lastName the last name of the student
     * @param address the address of the student
     * @param phone the phone number of the student
     * @param email the email address of the student
     * @param suBox the SU box number of the student
     */
    public Student(String firstName, String lastName, String address,
                   String phone, String email, int suBox) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.suBox = suBox;
    }

    /**
     * Get the first name of the student.
     *
     * @return the first name
     */
    public String getFirstName(){
        return this.firstName;
    }

    /**
     * Get the last name of the student.
     *
     * @return the last name
     */
    public String getLastName(){
        return this.lastName;
    }

    /**
     * Get the full address of the student.
     *
     * @return the full address
     */
    public String getAddress(){
        return this.address;
    }

    /**
     * Get the phone number of the student.
     *
     * @return the phone number
     */
    public String getPhone(){
        return this.phone;
    }

    /**
     * Get the email address of the student.
     *
     * @return the email address
     */
    public String getEmail(){
        return this.email;
    }

    /**
     * Get the SU box number of the student.
     *
     * @return the SU box number
     */
    public int getSuBox(){
        return this.suBox;
    }

    /**
     * Get the full name of the student (combination of first name and last name).
     *
     * @return the full name
     */
    public String getFullName(){
        return this.firstName + " " + this.lastName;
    }

    /**
     * Convert the Student object to a string representation.
     *
     * @return the string representation
     */
    @Override
    public String toString(){
        return this.firstName + " " + this.lastName + " | " +
                this.address + " | " + this.phone + " | " + this.email + " | " + this.suBox;
    }
}
