Students with smallest SU box:
Husam Abdalla | L4 Brunswick Apts. | 208-1238 | habdalla@bowdoin.edu | 1
Claire Aasen | D1 Brunswick Apts. | 208-1454 | caasen@bowdoin.edu | 1

Students with largest SU box:
Paul Sullivan | 201 Maine Hall | 208-1536 | psulliva@bowdoin.edu | 1015
Jiawei Zou | 416 West Hall | 208-2603 | jzou@bowdoin.edu | 1015

First student by last name:
Claire Aasen | D1 Brunswick Apts. | 208-1454 | caasen@bowdoin.edu | 1

Last student by last name:
Andrew deJong | 204 Winthrop Hall | 208-2202 | adejong@bowdoin.edu | 217

Student with most vowels in name:
Charlotte Alimanestianu | 403 Moore Hall | 208-2892 | calimane@bowdoin.edu | 11
Madeleine Livaudais | 404 Coleman Hall | 208-1344 | mlivauda@bowdoin.edu | 502
Ursula Moreno-VanderLaan | 057 Stowe Inn | 208-3260 | umoreno@bowdoin.edu | 745

Student with least vowels in name:
Hy Khong | 201 Maine Hall | 208-2614 | hkhong@bowdoin.edu | 419

Student with most occurrences of single digit in phone number:
Matthew Gutierrez | 304 Hyde Hall | 208-2223 | mgutierr@bowdoin.edu | 344
Skye Aresty | 402 Hyde Hall | 208-2226 | saresty@bowdoin.edu | 35
Caroline Bartlett | 303 Maine Hall | 208-2422 | cbartlet@bowdoin.edu | 33
Jasmine Bailey | J2 Brunswick Apts. | 208-1111 | jbailey@bowdoin.edu | 26
Gabriela Wilson | Off-Campus Study | 208-2292 | gwilson@bowdoin.edu | 988
William Powers | 102 Quinby House | 208-2922 | wpowers@bowdoin.edu | 603
Justin Dury-Agri | 210 Howell House | 208-2252 | jduryagr@bowdoin.edu | 204
Nicholas Saba | 14B Coles Tower | 208-2522 | nsaba@bowdoin.edu | 809
Bintou Kunjo | 031 30 College St. | 208-2722 | bkunjo@bowdoin.edu | 418
Diana Lee | 006 Mayflower Apts. | 208-1222 | dflee@bowdoin.edu | 503
Bianca Leos | 511 West Hall | 208-2220 | bleos@bowdoin.edu | 517
Stephanie Bond | 415 West Hall | 208-3222 | sbond2@bowdoin.edu | 110
Davis Unruh | 401 Maine Hall | 208-2822 | dunruh@bowdoin.edu | 928
Andrew deJong | 204 Winthrop Hall | 208-2202 | adejong@bowdoin.edu | 217
Dieu Ho | 403A Howard Hall | 208-2022 | dho@bowdoin.edu | 309
Caroline Moore | 021 Smith | 208-2888 | cmoore@bowdoin.edu | 640
Alison Considine | 206 Helmreich House | 208-2224 | aconsidi@bowdoin.edu | 140
Brenna Fischer | 501A Stowe Hall | 208-2225 | bfischer@bowdoin.edu | 228
Hannah Tennent | A4 Brunswick Apts. | 208-1888 | htennent@bowdoin.edu | 969
Stephen Strout | Off-Campus Study | 208-2221 | sstrout@bowdoin.edu | 947
Molly Soloff | E4 Brunswick Apts. | 208-2229 | msoloff@bowdoin.edu | 666
Helen Wieffering | 212 West Hall | 208-2122 | hwieffer@bowdoin.edu | 1002