import java.util.Scanner;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

/**
 * The `WordGen` class generates random text using a specified input file and a given value of `k`,
 * which indicates the level of analysis on the text.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.02.13
 */
public class WordGen {

    /**
     * The input file from which to generate text.
     */
    private String inputFile;

    /**
     * The `k` value to use for text generation.
     */
    private int k;

    /**
     * The `SequenceTable` used to generate text.
     */
    private SequenceTable sequenceTable;

    /**
     * Initializes a new instance of the `WordGen` class with default values.
     */
    public WordGen() {
        inputFile = "";
        k = -1;
        sequenceTable = new SequenceTable();
    }

    /**
     * Sets the input file for text generation.
     *
     * @param inputFile The path to the input file.
     */
    public void setInputFile(String inputFile) {
        this.inputFile = inputFile;
    }

    /**
     * Sets the `k` value for text generation.
     *
     * @param k The value of `k`.
     */
    public void setK(int k) {
        this.k = k;
    }

    /**
     * Generates the text based on the input file and `k` value.
     *
     * @return The generated text.
     */
    public String makeText() {
        if (inputFile.isEmpty() || k < 1) {
            return "Error: entered file can’t be read, or the value of k is invalid";
        }

        try {
            String content = readFileAsString(inputFile);
            if (content == null) {
                return "Error: Unable to read input file";
            }

            // If content is shorter than k, add space to match k-length
            if (content.length() < k) {
                for (int i = 0; i < k - content.length(); i++) {
                    content += " ";
                }
            }

            // Append first k-length sequence to content
            String sequence = content.substring(0, k) + " ";
            content = sequence + content;

            // If input ends with a unique k-length sequence, append it to itself
            String lastSequence = content.substring(content.length() - k).strip();
            if (content.lastIndexOf(lastSequence) == content.length() - k) {
                content += lastSequence + " ";
            }

            String[] sequences = extractSequences(content);
            buildSequenceTable(sequences);

            StringBuilder result = new StringBuilder();
            result.append(sequences[0]);
            for (int i = k; i < 500; i++) {
                String startSequence = result.substring(result.length() - k);
                char nextChar = sequenceTable.getNextCharacter(startSequence);
                result.append(nextChar);
            }
            return result.toString();
        } catch (IOException e) {
            return "Error: Unable to read input file";
        }
    }


    /**
     * Extracts character sequences from the input content.
     *
     * @param content The content from which to extract sequences.
     * @return An array of extracted sequences.
     */
    private String[] extractSequences(String content) {
        String[] sequences = new String[content.length() - k + 1];
        for (int i = 0; i < content.length() - k + 1; i++) {
            sequences[i] = content.substring(i, i + k);
        }
        return sequences;
    }

    /**
     * Builds the `SequenceTable` based on the extracted sequences.
     *
     * @param sequences The sequences from which to build the table.
     */
    private void buildSequenceTable(String[] sequences) {
        for (int i = 0; i < sequences.length - 1; i++) {
            String sequence = sequences[i];
            char nextChar = sequences[i + 1].charAt(k - 1);
            sequenceTable.updateSequence(sequence, nextChar);
        }
    }

    /**
     * Reads the content of a file as a string.
     *
     * @param filename The name of the file to read.
     * @return The content of the file as a string.
     * @throws IOException if an I/O error occurs reading from the file or a malformed or
     *                     unmappable byte sequence is read.
     */
    private String readFileAsString(String filename) throws IOException {
        return Files.readString(Paths.get(filename));
    }

    /**
     * Entry point of the program.
     *
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
        WordGen wordGen = new WordGen();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter file to read:");
        String inputFile = scanner.nextLine();
        wordGen.setInputFile(inputFile);

        System.out.println("Enter desired value of k:");
        int k = scanner.nextInt();
        wordGen.setK(k);

        String generatedText = wordGen.makeText();
        System.out.println(generatedText);

        scanner.close();
    }
}
