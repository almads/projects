import java.util.HashMap;

/**
 * This class represents a SequenceTable, which is used to store a mapping of sequences to their
 * corresponding FrequencyMaps. It also updates the FrequencyMap for a given sequence
 * with the next character.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.02.13
 */
public class SequenceTable {

    /** A HashMap representing the mapping of sequences to their corresponding FrequencyMaps. */
    private HashMap<String, FrequencyMap> sequenceMap;

    /**
     * Constructs a new SequenceTable with an empty sequence map.
     */
    public SequenceTable() {
        sequenceMap = new HashMap<>();
    }

    /**
     * Updates the FrequencyMap for the given sequence with the next character.
     * If the sequence does not exist in the sequence map,
     * it will be added with an empty FrequencyMap.
     *
     * @param sequence  The sequence of characters.
     * @param nextChar  The next character in the sequence.
     */
    public void updateSequence(String sequence, char nextChar) {
        sequenceMap.putIfAbsent(sequence, new FrequencyMap());
        FrequencyMap freqMap = sequenceMap.get(sequence);
        freqMap.updateFrequency(sequence, nextChar);
    }

    /**
     * Gets the next character based on the frequency of characters following the given sequence.
     * If the sequence is not found in the sequence map, the method will return
     * a null character ('\0') to indicate the sequence is unknown.
     *
     * @param sequence  The sequence of characters.
     * @return          The next character based on frequency.
     */
    public char getNextCharacter(String sequence) {
        if (!sequenceMap.containsKey(sequence))
            return '\0';

        FrequencyMap freqMap = sequenceMap.get(sequence);
        return freqMap.getNextCharacter(sequence);
    }
}
