import java.util.HashMap;
import java.util.Random;

/**
 * This class represents a FrequencyMap, which is used to track the frequency of characters
 * for each sequence of characters and generates the next character based on the frequencies
 * of characters following a given sequence.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.02.13
 */
public class FrequencyMap {

    /** A HashMap representing the frequencies of characters for each sequence of characters. */
    private HashMap<String, HashMap<Character, Integer>> frequencies;

    /**
     * Constructs a new FrequencyMap with an empty frequency map.
     */
    public FrequencyMap() {
        frequencies = new HashMap<>();
    }

    /**
     * Updates the frequency count for the given sequence and character. I
     * f the sequence does not exist in the frequency map,
     * it will be added with an empty frequency map.
     *
     * @param sequence  The sequence of characters.
     * @param nextChar  The next character in the sequence.
     */
    public void updateFrequency(String sequence, char nextChar) {
        frequencies.putIfAbsent(sequence, new HashMap<>());
        HashMap<Character, Integer> charFreq = frequencies.get(sequence);
        charFreq.put(nextChar, charFreq.getOrDefault(nextChar, 0) + 1);
    }

    /**
     * Gets the next character based on the frequency of characters following the given sequence.
     * If the sequence is not found, the method will return a null character ('\0')
     * to indicate the sequence is unknown.
     *
     * @param sequence  The sequence of characters.
     * @return         The next character based on frequency.
     */
    public char getNextCharacter(String sequence) {
        if (!frequencies.containsKey(sequence))
            return '\0'; // Handles unknown sequence

        HashMap<Character, Integer> charFreq = frequencies.get(sequence);
        int totalFreq = charFreq.values().stream().mapToInt(Integer::intValue).sum();
        int randIndex = new Random().nextInt(totalFreq);

        int cumulativeFreq = 0;
        for (char c : charFreq.keySet()) {
            cumulativeFreq += charFreq.get(c);
            if (randIndex < cumulativeFreq)
                return c;
        }
        return '\0'; // Fallback
    }
}
