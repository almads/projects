/**
 * The SudokuMove class represents a move in a Sudoku puzzle, including the digit placed
 * and the position.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.03.26
 */
public class SudokuMove {
    /**
     * The digit to be placed.
     */
    private int digit;

    /**
     * The row where the digit is placed.
     */
    private int row;

    /**
     * The column where the digit is placed.
     */
    private int col;

    /**
     * Constructs a SudokuMove object with the given digit, row, and column.
     *
     * @param givenDigit The digit to be placed.
     * @param givenRow   The row where the digit is placed.
     * @param givenCol   The column where the digit is placed.
     */
    public SudokuMove(int givenDigit, int givenRow, int givenCol) {
        this.digit = givenDigit;
        this.row = givenRow;
        this.col = givenCol;
    }

    /**
     * Gets the digit of the move.
     *
     * @return The digit of the move.
     */
    public int getDigit() {
        return this.digit;
    }

    /**
     * Gets the row of the move.
     *
     * @return The row of the move.
     */
    public int getRow() {
        return this.row;
    }

    /**
     * Gets the column of the move.
     *
     * @return The column of the move.
     */
    public int getCol() {
        return this.col;
    }
}
