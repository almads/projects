import java.util.Deque;
import java.util.ArrayDeque;

/**
 * This class provides functionality to solve a Sudoku puzzle.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.03.26
 */
public class SudokuSolver {
    /**
     * The Sudoku puzzle to be solved.
     */
    private SudokuPuzzle puzzle;

    /**
     * Constructs a SudokuSolver object with the given Sudoku puzzle.
     *
     * @param puzzle The Sudoku puzzle to be solved.
     */
    public SudokuSolver(SudokuPuzzle puzzle) {
        this.puzzle = puzzle;
    }

    /**
     * Gets the next possible move for a given cell in the Sudoku puzzle.
     *
     * @param lastDigit The last digit placed in the cell.
     * @param row       The row index of the cell.
     * @param col       The column index of the cell.
     * @return The next possible move as a SudokuMove object, or null if no move is possible.
     */
    private SudokuMove getNextMove(int lastDigit, int row, int col) {
        for (int i = lastDigit + 1; i <= 9; i++) {
            SudokuMove move = new SudokuMove(i, row, col);
            if (this.puzzle.isValidMove(move)) {
                return move;
            }
        }
        return null;
    }

    /**
     * Solves the Sudoku puzzle.
     *
     * @return The solved Sudoku puzzle.
     */
    public SudokuPuzzle solve() {
        Deque<SudokuMove> digitDeque = new ArrayDeque<>();
        boolean isBacktracking = false;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                SudokuMove move;
                if (puzzle.getValueAt(i, j) == 0 || isBacktracking) {
                    move = getNextMove(puzzle.getValueAt(i, j), i, j);
                    if (move == null) {
                        SudokuMove lastMove = digitDeque.pop();
                        puzzle.placeDigit(0, i, j);
                        i = lastMove.getRow();
                        j = lastMove.getCol() - 1;
                        isBacktracking = true;
                    } else {
                        digitDeque.push(move);
                        puzzle.placeDigit(move.getDigit(), move.getRow(), move.getCol());
                        isBacktracking = false;
                    }
                }
            }
        }
        return puzzle;
    }
}
