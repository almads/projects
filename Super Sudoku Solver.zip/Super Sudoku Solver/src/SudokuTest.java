import java.util.Scanner;

/**
 * A class to test Sudoku solving functionality.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.03.26
 */
public class SudokuTest {

    /**
     * Checks if the actual Sudoku puzzle matches the expected solution.
     *
     * @param actual   The actual Sudoku puzzle.
     * @param expected The expected solution.
     * @return True if the actual puzzle matches the expected solution, false otherwise.
     */
    public static boolean checkSolution(SudokuPuzzle actual, SudokuPuzzle expected) {
        return actual.equals(expected);
    }

    /**
     * Solves a Sudoku puzzle.
     *
     * @param puzzleFile    The file containing the Sudoku puzzle.
     * @param solutionFile  The file containing the solution (optional).
     * @return The solved Sudoku puzzle as a string.
     */
    public static String solveSudoku(String puzzleFile, String solutionFile) {
        SudokuPuzzle givenPuzzle = new SudokuPuzzle(puzzleFile);
        System.out.print("\nStarting puzzle: \n" + givenPuzzle);

        SudokuPuzzle givenSolution = new SudokuPuzzle(solutionFile);

        SudokuSolver solution = new SudokuSolver(givenPuzzle);
        SudokuPuzzle finalSolution = solution.solve();
        System.out.print("\nSolved puzzle: \n" + finalSolution);

        if (!solutionFile.equals("")) {
            if (checkSolution(finalSolution, givenSolution)) {
                System.out.println("\nSolution is correct!");
            } else {
                System.out.println("\nSolution is NOT correct!");
            }
        }

        return finalSolution.toString();
    }

    /**
     * Main method to test Sudoku solving functionality.
     *
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter filename of puzzle: ");
        String puzzleFileName = in.nextLine();
        System.out.print("Enter filename of solution (optional): ");
        String solutionFileName = in.nextLine();

        solveSudoku(puzzleFileName, solutionFileName);
    }
}
