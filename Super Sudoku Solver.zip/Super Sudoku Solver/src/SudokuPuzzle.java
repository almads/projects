import java.io.File;
import java.util.Scanner;

/**
 * This class represents a Sudoku puzzle.
 *
 * @author Alma Dudas
 * @version 1.0 Build 2024.03.26
 */
public class SudokuPuzzle {

    /**
     * The grid representing the Sudoku puzzle.
     */
    private int[][] puzzleGrid;

    /**
     * Constructs a SudokuPuzzle object by reading from a file.
     *
     * @param fileName The name of the file containing the Sudoku puzzle.
     */
    public SudokuPuzzle(String fileName) {
        this.puzzleGrid = new int[9][9];
        try {
            Scanner scan = new Scanner(new File(fileName));
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    this.puzzleGrid[i][j] = scan.nextInt();
                }
            }
            scan.close();
        } catch (Exception e) {
            // Failed to read file
            return;
        }
    }

    /**
     * Gets the value at the specified row and column in the Sudoku puzzle.
     *
     * @param row The row index.
     * @param col The column index.
     * @return The value at the specified position.
     */
    public int getValueAt(int row, int col) {
        return this.puzzleGrid[row][col];
    }

    /**
     * Places a digit at the specified row and column in the Sudoku puzzle.
     *
     * @param digit The digit to be placed.
     * @param row   The row index.
     * @param col   The column index.
     */
    public void placeDigit(int digit, int row, int col) {
        this.puzzleGrid[row][col] = digit;
    }

    /**
     * Checks if a cell in the Sudoku puzzle is empty.
     *
     * @param row The row index.
     * @param col The column index.
     * @return True if the cell is empty, false otherwise.
     */
    public boolean isEmpty(int row, int col) {
        return this.puzzleGrid[row][col] == 0;
    }

    /**
     * Checks if this Sudoku puzzle is equal to another Sudoku puzzle.
     *
     * @param obj The other object to compare.
     * @return True if the puzzles are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof SudokuPuzzle) {
            SudokuPuzzle solutionFile = (SudokuPuzzle) obj;
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    if (this.puzzleGrid[i][j] != solutionFile.getValueAt(i, j)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     * Checks if a move is valid in the Sudoku puzzle.
     *
     * @param move The move to be checked.
     * @return True if the move is valid, false otherwise.
     */
    public boolean isValidMove(SudokuMove move) {
        for (int j = 0; j < 9; j++) {
            if (move.getDigit() == this.puzzleGrid[move.getRow()][j])
                return false;
        }

        for (int i = 0; i < 9; i++) {
            if (move.getDigit() == this.puzzleGrid[i][move.getCol()])
                return false;
        }

        int boxStartRow = (move.getRow() / 3) * 3;
        int boxStartCol = (move.getCol() / 3) * 3;

        for (int i = boxStartRow; i < boxStartRow + 3; i++) {
            for (int j = boxStartCol; j < boxStartCol + 3; j++) {
                if (this.puzzleGrid[i][j] == move.getDigit()) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Provides a string representation of the Sudoku puzzle.
     *
     * @return A string representation of the Sudoku puzzle.
     */
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (puzzleGrid[i][j] == 0) {
                    result.append("_").append(" ");
                }
                else{
                    result.append(this.puzzleGrid[i][j]).append(" ");
                }
            }
            result.append("\n");
        }
        return result.toString();
    }
}